import { createStore, combineReducers, applyMiddleware } from "redux";
import { bankReducer } from "../reducers/Bank-reducer";
import { productsReducer } from "../reducers/Product-reducer";
import thunk from "redux-thunk";

const appReducer = combineReducers({
  bank: bankReducer,
  products: productsReducer
});

export const store = createStore(appReducer, applyMiddleware(thunk));
