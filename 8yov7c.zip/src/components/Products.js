import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { add_products, fetchProducts } from "../actions/Product-action";

function Products() {
  const products = useSelector((state) => state.products);
  const dispatch = useDispatch();
  console.log(products);
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  return (
    <>
      <h1>Products</h1>
      <button
        onClick={() => {
          dispatch(add_products({ id: 2, title: "product2" }));
        }}
      >
        Add Product
      </button>
      {products.map((product) => (
        <h2 key={product.id}>{product.title}</h2>
      ))}
    </>
  );
}
export default Products;
