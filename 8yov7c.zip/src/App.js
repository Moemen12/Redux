import "./styles.css";
import { useSelector, useDispatch } from "react-redux";
import { deposite, withdraw } from "./actions/Bank-action";
import Products from "./components/Products";

export default function App() {
  const state = useSelector((state) => state.bank);
  const dispatch = useDispatch();
  console.log(state);
  return (
    <div className="App">
      <p>Bank Account Balance : {state}</p>
      <button
        onClick={() => {
          dispatch(withdraw(100));
        }}
      >
        Withdraw
      </button>
      <button
        onClick={() => {
          dispatch(deposite(100));
        }}
      >
        Deposite
      </button>
      <Products />
    </div>
  );
}
